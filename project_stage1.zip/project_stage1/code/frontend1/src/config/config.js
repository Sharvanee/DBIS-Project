// This is url for the backend API
export const apiUrl = 'http://localhost:4000';